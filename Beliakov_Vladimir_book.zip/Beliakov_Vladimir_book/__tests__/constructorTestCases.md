### **constructor(jsondata)**

Initializes BookRegister object

> Parameters:
>
> > The data storage json object is passed as a parameter to the constructor.

> Returns:
>
> >

> Throws:
>
> > If the parameter is missing, constructor throws an error `"data storage missing"`

## Testing constructor

throws an exception `"data storage missing"` if parameter is missing
